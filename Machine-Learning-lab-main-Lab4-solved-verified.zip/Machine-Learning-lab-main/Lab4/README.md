# Lab 4: Data Quality Assessment & Preprocessing

## Dataset
This lab uses the same dataset from the previous labs: `data.xlsx`.

The dataset contains student performance features:

- StudentID
- StudyHours
- AttendanceRate
- SleepHours
- AssignmentsCompleted
- FinalScore

## Objective
The goal of this lab is to assess data quality and apply preprocessing techniques before training machine learning models.

## Tasks Completed

1. Loaded the student dataset.
2. Checked data types, missing values, duplicate rows, and descriptive statistics.
3. Demonstrated missing value handling using median imputation.
4. Detected outliers using the IQR method.
5. Applied Min-Max normalization.
6. Applied Z-score standardization.
7. Applied PCA and interpreted the explained variance.

## Files

- `ARTI308_Lab4_Preprocessing.ipynb` — Main notebook solution.
- `data.xlsx` — Student dataset used in previous labs.
- Images — Supporting lab images from the instructor material.

## Notes

`StudentID` was excluded from model features because it is only an identifier.
`FinalScore` was treated as the target variable.
